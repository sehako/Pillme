<template>
  <div class="image-analysis-container flex flex-col items-center justify-center h-screen-custom bg-gray-100">
    <input type="file" @change="handleFileChange" accept="image/*" class="mb-4 p-2 border rounded" v-if="!imagePreview"/>

    <!-- 📌 이미지 미리보기 -->
    <div v-if="imagePreview" class="mb-4">
      <h2 class="text-lg font-semibold">📷 분석할 이미지</h2>
      <img :src="imagePreview" alt="Preview" class="max-h-[300px] object-contain border rounded" />
    </div>

    <button @click="analyzeImage" :disabled="!imagePreview || isLoading" class="analyze-btn">
      {{ isLoading ? '분석 중...' : '이미지 분석하기' }}
    </button>

    <div v-if="isLoading" class="text-center text-gray-600 mt-4">📡 분석 중입니다...</div>

    <div v-if="error" class="text-red-500 mt-4 p-3 bg-red-50 rounded">
      ❌ {{ error }}
    </div>

    <!-- 📌 분석 결과 다이얼로그 -->
    <div v-if="results.length > 0" class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
      <div class="bg-white p-6 rounded-lg max-w-md w-full">
        <h2 class="text-lg font-semibold mb-2">📄 분석 결과</h2>
        <ul>
          <li v-for="(result, index) in results" :key="index" class="text-gray-700 py-1">
            {{ result.matched_drug }}
          </li>
        </ul>
        <button @click="results = []" class="confirm-btn mt-4">✔ 확인</button>
      </div>
    </div>

    <!-- 📌 분석 실패 메시지 -->
    <div v-if="isFailed" class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
      <div class="bg-white p-6 rounded-lg max-w-md w-full text-center">
        <h2 class="text-lg font-semibold text-red-600">🚫 분석 실패</h2>
        <p class="text-gray-700 mt-2">이미지를 인식할 수 없습니다.</p>
        <button @click="resetAnalysis" class="confirm-btn mt-4">🔄 다시 시도하기</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";

const route = useRoute();
const imagePreview = ref(null);
const isLoading = ref(false);
const error = ref(null);
const results = ref([]);
const isFailed = ref(false);
const selectedFile = ref(null);

// ✅ Base64 데이터를 Blob으로 변환하는 함수
const base64ToBlob = (base64) => {
const byteCharacters = atob(base64.split(",")[1]);
const byteNumbers = new Array(byteCharacters.length).fill(0).map((_, i) => byteCharacters.charCodeAt(i));
const byteArray = new Uint8Array(byteNumbers);
return new Blob([byteArray], { type: "image/png" });
};

// ✅ 파일 선택 핸들러
const handleFileChange = (event) => {
const file = event.target.files[0];
if (!file) {
  error.value = "파일이 선택되지 않았습니다.";
  return;
}

// ✅ 파일 확장자 및 크기 확인
if (!file.type.startsWith("image/")) {
  error.value = "이미지 파일만 업로드 가능합니다.";
  return;
}
const maxSize = 5 * 1024 * 1024;
if (file.size > maxSize) {
  error.value = "파일 크기가 5MB를 초과할 수 없습니다.";
  return;
}

selectedFile.value = file;

const reader = new FileReader();
reader.onload = (e) => {
  imagePreview.value = e.target.result;
};
reader.readAsDataURL(file);
};

// ✅ `CameraCapture.vue`에서 촬영한 이미지 데이터를 불러오기
onMounted(() => {
const imageQuery = route.query.image;
if (imageQuery) {
  imagePreview.value = decodeURIComponent(imageQuery);
  analyzeImage(); // ✅ 자동 분석 시작
}
});

// ✅ 분석 실패 후 다시 시도하기 버튼을 누르면 초기화
const resetAnalysis = () => {
isFailed.value = false;
results.value = [];
error.value = null;
isLoading.value = false;
};

// ✅ 이미지 분석 함수
const analyzeImage = async () => {
if (!imagePreview.value) {
  error.value = "분석할 이미지가 없습니다.";
  return;
}

isLoading.value = true;
error.value = null;
results.value = [];
isFailed.value = false;

const formData = new FormData();

if (selectedFile.value) {
  // ✅ 사용자가 직접 업로드한 파일
  formData.append("file", selectedFile.value);
} else {
  // ✅ Base64 이미지를 Blob으로 변환 후 서버로 전송
  const blob = base64ToBlob(imagePreview.value);
  formData.append("file", blob, "captured_image.png");
}

try {
  const response = await fetch("http://localhost:8000/analyze-image/", {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    throw new Error(`이미지 분석 중 오류 발생: ${response.statusText}`);
  }

  const data = await response.json();

  if (!data || !Array.isArray(data) || data.length === 0) {
    throw new Error("이미지를 인식할 수 없습니다.");
  }

  results.value = data;
} catch (err) {
  error.value = err.message;
  isFailed.value = true; // 🚫 분석 실패 UI 표시
} finally {
  isLoading.value = false;
}
};
</script>
